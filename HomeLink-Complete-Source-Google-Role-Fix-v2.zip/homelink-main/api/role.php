<?php
declare(strict_types=1);
require_once __DIR__ . '/_bootstrap.php';
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') send_json(405, ['error' => 'Method not allowed.']);
$token = bearer_token();
$user = authenticated_user($token);
$id = rawurlencode($user['id']);
[$status, $rows] = supabase_request('GET', '/rest/v1/profiles?id=eq.' . $id . '&select=id,role,full_name,email&limit=1', $token);
if ($status !== 200 || !isset($rows[0]['role'])) send_json(404, ['error' => 'HomeLink profile not found.']);
$profile = $rows[0];
$role = strtolower(trim((string)$profile['role']));
if (!in_array($role, ['tenant','manager','contractor'], true)) send_json(403, ['error' => 'Invalid account role.']);
$expected = strtolower(trim((string)($_GET['expected_role'] ?? '')));
if ($expected !== '' && $expected !== $role) {
    send_json(403, ['error' => 'This account cannot access the selected role.', 'registered_role' => $role]);
}
send_json(200, ['user_id' => $user['id'], 'role' => $role, 'full_name' => $profile['full_name'] ?? null]);
