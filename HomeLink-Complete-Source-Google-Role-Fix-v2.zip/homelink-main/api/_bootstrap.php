<?php
declare(strict_types=1);
/* Shared HTTP helpers. Never put a Supabase service_role key in this app. */

function send_json(int $status, array $body): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($body, JSON_UNESCAPED_SLASHES);
    exit;
}

function bearer_token(): string {
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if (!preg_match('/^Bearer\s+([\w.\-~+\/=]+)$/i', $header, $match)) {
        send_json(401, ['error' => 'Sign in to continue.']);
    }
    return $match[1];
}

function supabase_request(string $method, string $path, string $token, ?array $payload = null): array {
    $base = rtrim((string)getenv('SUPABASE_URL'), '/');
    $key = (string)getenv('SUPABASE_ANON_KEY');
    if ($base === '' || $key === '') send_json(503, ['error' => 'Backend not configured.']);
    if (!filter_var($base, FILTER_VALIDATE_URL) || parse_url($base, PHP_URL_SCHEME) !== 'https') {
        send_json(503, ['error' => 'Invalid backend configuration.']);
    }
    $curl = curl_init($base . $path);
    if ($curl === false) send_json(503, ['error' => 'HTTP client unavailable.']);
    $headers = ['Authorization: Bearer ' . $token, 'apikey: ' . $key, 'Accept: application/json'];
    if ($payload !== null) $headers[] = 'Content-Type: application/json';
    curl_setopt_array($curl, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => 12,
        CURLOPT_FOLLOWLOCATION => false,
    ]);
    if ($payload !== null) curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($payload, JSON_UNESCAPED_SLASHES));
    $content = curl_exec($curl);
    $status = (int)curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $failed = curl_errno($curl) !== 0;
    curl_close($curl);
    if ($failed || $content === false) send_json(502, ['error' => 'Account service unavailable.']);
    $json = json_decode((string)$content, true);
    return [$status, is_array($json) ? $json : []];
}

function authenticated_user(string $token): array {
    [$status, $user] = supabase_request('GET', '/auth/v1/user', $token);
    if ($status !== 200 || empty($user['id']) || !is_string($user['id'])) {
        send_json(401, ['error' => 'Session expired. Please sign in again.']);
    }
    return $user;
}
