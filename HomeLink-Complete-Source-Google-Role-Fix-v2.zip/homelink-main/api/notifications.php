<?php
declare(strict_types=1);
require_once __DIR__ . '/_bootstrap.php';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!in_array($method, ['GET','PATCH'], true)) send_json(405, ['error' => 'Method not allowed.']);
$token = bearer_token();
$user = authenticated_user($token);
$filter = 'user_id=eq.' . rawurlencode($user['id']);
if ($method === 'GET') {
    [$status, $rows] = supabase_request('GET', '/rest/v1/notifications?' . $filter . '&select=id,request_id,type,title,message,is_read,created_at&order=created_at.desc&limit=30', $token);
    if ($status !== 200) send_json(502, ['error' => 'Could not load notifications.']);
    send_json(200, ['notifications' => $rows]);
}
$raw = file_get_contents('php://input', false, null, 0, 4096);
$body = json_decode($raw === false ? '' : $raw, true);
if (!is_array($body)) send_json(400, ['error' => 'Invalid JSON body.']);
if (!empty($body['all'])) {
    $path = '/rest/v1/notifications?' . $filter . '&is_read=eq.false';
} elseif (isset($body['id']) && ctype_digit((string)$body['id'])) {
    $path = '/rest/v1/notifications?' . $filter . '&id=eq.' . rawurlencode((string)$body['id']);
} else {
    send_json(400, ['error' => 'Provide a notification id or all=true.']);
}
[$status] = supabase_request('PATCH', $path, $token, ['is_read'=>true]);
if ($status < 200 || $status >= 300) send_json(502, ['error' => 'Could not mark notifications as read.']);
send_json(200, ['success'=>true]);
