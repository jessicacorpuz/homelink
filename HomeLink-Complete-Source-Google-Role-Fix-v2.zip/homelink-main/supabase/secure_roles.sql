-- HomeLink role allowlist / one-role-per-user enforcement.
-- Run in Supabase SQL Editor AFTER reviewing your current profiles/auth triggers.
-- Back up existing triggers and existing manager/contractor profiles first.
-- For future Manager/Contractor signups, pre-approve their email addresses in
-- public.homelink_role_approvals using SQL Editor (NEVER from a public client).

create table if not exists public.homelink_role_approvals (
    email text primary key,
    role text not null check (role in ('manager', 'contractor')),
    created_at timestamptz not null default now(),
    constraint homelink_role_approvals_lower_email check (email = lower(trim(email)))
);
alter table public.homelink_role_approvals enable row level security;
revoke all on public.homelink_role_approvals from anon, authenticated;

-- Inserts default to Tenant unless the verified email is pre-approved. This
-- BEFORE INSERT trigger also protects existing signup triggers that copy role
-- from untrusted auth.user_metadata.
create or replace function public.homelink_enforce_profile_role()
returns trigger language plpgsql security definer set search_path = public
as $$
declare v_approved text;
begin
    if tg_op = 'INSERT' then
        select role into v_approved
        from public.homelink_role_approvals
        where email = lower(trim(new.email));
        new.role := coalesce(v_approved, 'tenant');
    elsif tg_op = 'UPDATE' then
        if new.role is distinct from old.role and auth.uid() is not null then
            raise exception 'Account role is fixed. Contact an administrator to change it.';
        end if;
    end if;
    return new;
end;
$$;

drop trigger if exists trg_homelink_enforce_profile_role on public.profiles;
create trigger trg_homelink_enforce_profile_role
before insert or update of role on public.profiles
for each row execute function public.homelink_enforce_profile_role();

-- Make sure new Google OAuth users get a profile, even if the normal password
-- registration code path is skipped. Does not overwrite an existing profile.
-- BEFORE INSERT above resolves tenant/approved role.
create or replace function public.homelink_bootstrap_profile()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
    insert into public.profiles (id,email,full_name,role)
    values (
       new.id,
       new.email,
       coalesce(nullif(new.raw_user_meta_data->>'full_name',''),
                nullif(new.raw_user_meta_data->>'name',''),
                split_part(coalesce(new.email,''),'@',1)),
       'tenant'
    ) on conflict (id) do nothing;
    return new;
end;
$$;

drop trigger if exists trg_homelink_bootstrap_profile on auth.users;
create trigger trg_homelink_bootstrap_profile
  after insert on auth.users
  for each row execute function public.homelink_bootstrap_profile();

-- Example: approve BEFORE signup, as database administrator:
-- INSERT INTO public.homelink_role_approvals (email, role)
-- VALUES ('manager@example.com', 'manager')
-- ON CONFLICT (email) DO UPDATE SET role=excluded.role;
-- Existing accounts are NOT silently changed. Correct them manually after
-- verifying the user and checking any associated records.
