/* HomeLink auth UI: inline validation, fixed-role login and Google OAuth intent. */
(() => {
  'use strict';
  const client = () => window.supabaseClient;
  const home = { tenant: 'pages/tenant_dashboard.html', manager: 'pages/manager_dashboard.html', contractor: 'pages/contractor_view.html' };
  const label = role => ({tenant:'Tenant',manager:'Manager',contractor:'Contractor'}[role] || 'Unknown');
  const OAUTH_KEY = 'homelinkOAuthIntent';
  const pageIsSignup = /(?:^|\/)signup\.html$/i.test(location.pathname);
  const $ = id => document.getElementById(id);

  function status(message, kind = 'error') {
    const form = $(pageIsSignup ? 'signup-form' : 'login-form');
    if (!form) return;
    let target = $('homelink-form-status');
    if (!target) {
      target = document.createElement('p');
      target.id = 'homelink-form-status';
      target.setAttribute('role', 'alert');
      target.setAttribute('aria-live', 'polite');
      form.prepend(target);
    }
    target.textContent = message || '';
    target.className = 'homelink-form-status ' + (kind === 'success' ? 'success' : 'error');
    target.hidden = !message;
  }

  function fieldError(id, message) {
    const input = $(id);
    if (!input) return;
    const group = input.closest('.form-group');
    if (!group) return;
    let error = group.querySelector('.homelink-field-error');
    if (!error) {
      error = document.createElement('small');
      error.className = 'homelink-field-error';
      error.setAttribute('role', 'alert');
      group.append(error);
    }
    error.textContent = message || '';
    error.hidden = !message;
    input.classList.toggle('homelink-invalid', Boolean(message));
    if (message) input.setAttribute('aria-invalid', 'true');
    else input.removeAttribute('aria-invalid');
  }

  function clearErrors() {
    status('');
    for (const id of ['full-name', 'email', 'password', 'confirm-password']) fieldError(id, '');
  }
  function emailValid(v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); }
  function validateSignup() {
    const name = $('full-name').value.trim(), email = $('email').value.trim();
    const pass = $('password').value, confirm = $('confirm-password').value;
    let valid = true;
    const check = (id, msg) => { fieldError(id, msg); if (msg) valid = false; };
    check('full-name', !name ? 'Full name is required *' : '');
    check('email', !email ? 'Email address is required *' : !emailValid(email) ? 'Enter a valid email address.' : '');
    check('password', !pass ? 'Password is required *' : pass.length < 8 ? 'Password must be at least 8 characters.' : '');
    check('confirm-password', !confirm ? 'Please confirm your password *' : confirm !== pass ? 'Passwords do not match.' : '');
    return valid;
  }
  function validateSignin() {
    const email = $('email').value.trim(), pass = $('password').value;
    fieldError('email', !email ? 'Email address is required *' : !emailValid(email) ? 'Enter a valid email address.' : '');
    fieldError('password', !pass ? 'Password is required *' : '');
    return Boolean(email && emailValid(email) && pass);
  }
  function setBusy(id, text, busy, normal) {
    const button = $(id);
    if (button) { button.disabled = busy; button.textContent = busy ? text : normal; }
  }
  function selectedRole() { return String($('selected-role')?.value || '').toLowerCase().trim(); }
  function normalizeRole(role) {return String(role ?? '').trim().toLowerCase();}
  function clearOAuthIntent() {
    try {sessionStorage.removeItem(OAUTH_KEY);} catch (_) {}
    try {localStorage.removeItem(OAUTH_KEY);} catch (_) {}
  }
  function mismatch(actual, requested) {
    return `This account is registered as ${label(actual)}. You cannot sign in as ${label(requested)}. One account has one HomeLink role.`;
  }
  async function profileFor(user) {
    const {data, error} = await client().from('profiles')
      .select('id,role,full_name,email').eq('id', user.id).maybeSingle();
    if (error) throw new Error('HomeLink profile could not be loaded: ' + error.message);
    if (data) data.role = normalizeRole(data.role);
    return data;
  }
  async function signIn() {
    clearErrors();
    if (!validateSignin()) return;
    const role = selectedRole();
    if (!home[role]) {status('Select Tenant, Manager, or Contractor before signing in.');return;}
    setBusy('sign-in-button', 'Signing in...', true);
    try {
      const {data, error} = await client().auth.signInWithPassword({email:$('email').value.trim(),password:$('password').value});
      if (error || !data?.user) { fieldError('password','Invalid email or password.'); status('Invalid email or password. Please try again.'); return; }
      const profile = await profileFor(data.user);
      if (!profile || !home[profile.role]) {
        await client().auth.signOut();
        status('No valid HomeLink role was found for this account. Contact the administrator.');
        return;
      }
      if (profile.role !== role) {
        await client().auth.signOut();
        status(mismatch(profile.role, role));
        return;
      }
      location.assign(home[profile.role]);
    } catch (err) { console.error('HomeLink login:', err); status('Sign-in failed. Please try again.'); }
    finally { setBusy('sign-in-button', '', false, 'Sign in'); }
  }

  async function signUp() {
    clearErrors();
    if (!validateSignup()) return;
    const role = selectedRole();
    if (!home[role]) {status('Select an account role before registering.');return;}
    setBusy('sign-up-button', 'Creating account...', true);
    try {
      const {data,error} = await client().auth.signUp({
        email:$('email').value.trim(), password:$('password').value,
        options:{data:{full_name:$('full-name').value.trim(), requested_role:role}}
      });
      if (error) {status(error.message); return;}
      if (!data?.user) {status('Account could not be created.');return;}
      if (!data.session) {
        status('Account request received. Check your email and confirm your account before signing in.', 'success');
        return;
      }
      const profile = await profileFor(data.user);
      if (!profile || !home[profile.role]) {
        await client().auth.signOut();
        status('Your HomeLink profile was not created. Contact an administrator.'); return;
      }
      if (profile.role !== role) {
        await client().auth.signOut();
        status(mismatch(profile.role,role) + (role !== 'tenant' ? ' Manager/Contractor access requires prior approval.' : ''));
        return;
      }
      location.assign(home[profile.role]);
    } catch (err) {console.error('HomeLink signup:',err); status('Could not create your account. Please try again.');}
    finally {setBusy('sign-up-button','',false,'Create account');}
  }

  async function googleAuth(mode) {
    clearErrors();
    const role = selectedRole();
    if (!home[role]) {status('Select Tenant, Manager, or Contractor first.'); return;}
    // Capture the selected login tab BEFORE the Google redirect.
    // This is a comparison-only value, never an authorization grant.
    const intent = JSON.stringify({role, mode, at:Date.now()});
    try {
      sessionStorage.setItem(OAUTH_KEY, intent);
      // Some mobile Google consent flows resume in a separate browsing context.
      // localStorage fallback allows validation there (still checked against DB).
      localStorage.setItem(OAUTH_KEY, intent);
    } catch(err) {
      console.warn('Could not persist Google login intent:', err);
      clearOAuthIntent();
      status('Google login cannot start in this browser. Allow site storage and retry.');
      return;
    }
    try {
      const callback = new URL('google-callback.html',location.href).href;
      const {error} = await client().auth.signInWithOAuth({
        provider:'google', options:{redirectTo:callback}
      });
      if (error) {clearOAuthIntent(); status(error.message);}
    } catch (err) {
      clearOAuthIntent();console.error(err);
      status('Google sign-in failed. Please try again.');
    }
  }
  async function resetPassword() {
    clearErrors();
    const email = $('email').value.trim();
    if (!email || !emailValid(email)) {fieldError('email','Enter your email address to reset your password.');return;}
    try {
      const {error} = await client().auth.resetPasswordForEmail(email, {redirectTo: location.origin+'/reset-password.html'});
      if (error) throw error;
      status('If this address is registered, password reset instructions will arrive by email.', 'success');
    } catch(err) {console.error(err); status('Could not send password reset email. Try again later.');}
  }

  function init() {
    document.querySelectorAll('input').forEach(input => input.addEventListener('input', () => fieldError(input.id,'')));
    document.querySelectorAll('.role-tab').forEach(tab => tab.addEventListener('click',()=>status('')));
    const fromOAuth = sessionStorage.getItem('homelinkAuthError');
    if (fromOAuth) { sessionStorage.removeItem('homelinkAuthError'); status(fromOAuth); }
    if (pageIsSignup) {
      window.signUp = signUp;
      window.signUpWithGoogle = () => googleAuth('signup');
    } else {
      window.signIn = signIn;
      window.signInWithGoogle = () => googleAuth('signin');
      window.resetPassword = resetPassword;
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded',init);
  else init();
})();
