/* Backup refresh if Supabase Realtime briefly disconnects or a device wakes up. */
(() => {
  'use strict';
  const refresh = () => {
    if (document.visibilityState !== 'visible') return;
    const api = window.HomeLinkNotifications;
    if (api && typeof api.refresh === 'function') api.refresh().catch(console.error);
  };
  window.addEventListener('focus', refresh);
  document.addEventListener('visibilitychange', refresh);
  // Realtime remains the primary transport; polling is only a fallback.
  setInterval(refresh, 60000);
})();
