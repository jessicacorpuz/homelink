/* Client-side navigation guard (database RLS must also enforce authorization). */
window.HomeLinkPageGuard = async function(expectedRole) {
  const client=window.supabaseClient;
  try {
    const {data,error}=await client.auth.getUser();
    if(error||!data.user){location.replace('../index.html');return false;}
    const p=await client.from('profiles').select('role').eq('id',data.user.id).single();
    if(p.error||p.data?.role!==expectedRole){
      await client.auth.signOut();
      sessionStorage.setItem('homelinkAuthError',`This account cannot access the ${expectedRole} area. Please sign in with the correct role.`);
      location.replace('../index.html');return false;
    }
    return true;
  } catch(err) {
    console.error('HomeLink role check:',err);
    location.replace('../index.html'); return false;
  }
};
