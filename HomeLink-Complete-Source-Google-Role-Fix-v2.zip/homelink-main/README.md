# HomeLink — Complete Source Code

**Based on the full `jessicacorpuz/homelink` GitHub `main` source reviewed October 14, 2026**, with the authentication, Google role protection, validation, notification recovery and optional PHP code added.

## Included

- `index.html`, `signup.html`, `google-callback.html`, `reset-password.html`
- Every original page in `pages/`: tenant, manager, contractor, property, profile, and maintenance workflows
- Original CSS/JavaScript and Supabase client; new inline validation and role-guard JavaScript
- Existing Python maintenance API (`api/maintenance.py`)
- Optional PHP endpoints (`api/role.php`, `api/notifications.php`, shared `_bootstrap.php`)
- Supabase database scripts (`supabase/notifications.sql`, `supabase/secure_roles.sql`)
- `vercel.json`, sample environment configuration, and `tests/test-google-roles.mjs`

## Deployment

1. Deploy this entire folder to your hosting platform (the existing Python maintenance endpoint assumes Vercel-compatible Python functions). The PHP endpoints use `vercel-php@0.8.0`, a **community runtime**; test whether the version is supported by your deployment environment. PHP is optional; the frontend does not depend on it.
2. Confirm the Supabase credentials in `static/supabase.js` point to **your** project and use a publishable/anon key, never a `service_role` key. Set `SUPABASE_URL` and `SUPABASE_ANON_KEY` as server environment variables for the API endpoints. If migrating to your own Supabase, update the browser URL/key.
3. In Supabase SQL Editor, **review and test** `supabase/secure_roles.sql` in a development database (it creates profile/auth triggers; check existing triggers first). Then run `supabase/notifications.sql` to install notification triggers, RLS, and Realtime publication. Merely uploading SQL files does not run them.
4. Configure Supabase Auth email verification, Google provider, your production Site URL and the allowed callback URLs `<SITE>/google-callback.html` and `<SITE>/reset-password.html`.
5. Pre-approve new Manager or Contractor email addresses in `public.homelink_role_approvals` before registration. Example SQL is included in `secure_roles.sql`. **One Supabase auth user has one profile role**. The browser's role selection can never grant privileges.
6. Audit policies for `profiles`, `properties`, `maintenance_requests`, `maintenance_media`, `repair_updates` and Storage buckets. This repository does **not** include a complete schema or RLS definitions for the original app tables; back up and check the existing Supabase project. Frontend role guards cannot replace database permissions.
7. Test sign-in using separate Tenant/Manager/Contractor accounts and check notifications on actual data.

## Included changes

- Red inline validation for empty fields, bad email addresses, wrong credentials, and password confirmation
- Google callback checks the database role versus the selected role, preventing Tenant users from entering Manager or Contractor dashboards
- Manager/Contractor registration requires database-side preapproval; protected existing roles remain unchanged
- New profile bootstrap trigger for Google identity creation (after review of existing database triggers)
- Existing notifications preserved with focus/reconnect badge refresh fallback
- Optional authenticated PHP role and notification API endpoints
- Password recovery page and safer filename display for maintenance attachments
- Removed a legacy `signIn()` mock that redirected without validating credentials

## Testing

```
node tests/test-google-roles.mjs
php -l api/role.php
php -l api/notifications.php
python -m py_compile api/maintenance.py
```

These are source/static tests. Live hosting, Supabase OAuth, privileged database policies, Realtime delivery and upload permissions must be verified with a configured instance.

## Important note about wrong-role accounts

If a tester has already been assigned `tenant` in the Supabase `profiles` table when the intended role is `manager` or `contractor`, **do not change the role from JavaScript**. A trusted database administrator should verify the account and explicitly update the profile after reviewing associated records. New registration alone does not migrate existing accounts.

## Google OAuth wrong-role tester report (October 14, 2026)

If a Tenant chooses **Manager** or **Contractor**, HomeLink must **reject**
Google login with a visible red error. A Google identity cannot change an
existing account's role by selecting a different tab. The fix is in
`static/js/auth-ui.js` and `google-callback.html` and is also enforced by
`supabase/secure_roles.sql` when correctly installed.

* Upload **all** files in this ZIP to the deployed site, particularly `index.html`,
  `signup.html`, `static/js/auth-ui.js`, and `google-callback.html`.
* Ensure the site is serving the new files (check the network response for
  `auth-ui.js?v=20261014-rolefix2`). Old deployments and browser caches are a
  common reason testers still see the previous Google-only behavior.
* Configure the Google redirect allowlist for `<SITE>/google-callback.html`
  and enable the Google provider in Supabase Auth.
* Install `secure_roles.sql` only **after** reviewing existing database triggers.
  The ZIP does not modify the live database automatically.
* If a Google account was already recorded with the **wrong** role, ask an
  administrator to verify and correct its `profiles` row: public signup
  must never upgrade roles.
* Test a Tenant choosing Manager and Contractor via Google (both must be
  denied), then test an approved Manager choosing Manager (must succeed).
* The callback stores the selected role only to compare it with the database;
  modifying that stored selection never grants access. Enforce data permissions
  with Supabase RLS, not just JavaScript page checks.
