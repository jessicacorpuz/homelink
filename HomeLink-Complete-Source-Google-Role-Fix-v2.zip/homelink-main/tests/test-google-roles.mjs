// Lightweight auth callback tests; no Supabase credentials required.
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const html=fs.readFileSync(new URL('../google-callback.html',import.meta.url),'utf8');
const inline=[...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g)].map(m=>m[1]).filter(Boolean).at(-1);
async function run({existingRole,requestedRole,mode='signin',age=1000,storage='session',omitIntent=false}) {
  const intent=JSON.stringify({mode,role:requestedRole,at:Date.now()-age});
  const store=new Map(omitIntent || storage==='local' ? [] : [['homelinkOAuthIntent',intent]]);
  const localStore=new Map(omitIntent || storage==='session' ? [] : [['homelinkOAuthIntent',intent]]);
  const dest=[];let signOut=0;
  const sessionStorage={getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v),removeItem:k=>store.delete(k)};
const localStorage={getItem:k=>localStore.get(k)||null,removeItem:k=>localStore.delete(k)};
  const client={auth:{getSession:async()=>({data:{session:{user:{id:'test-user',email:'user@example.com'}}},error:null}),signOut:async()=>{signOut++;}},from:()=>({select:()=>({eq:()=>({maybeSingle:async()=>({data:existingRole?{id:'test-user',role:existingRole}:null,error:null})})})})};
  const context={window:{supabaseClient:client},sessionStorage,localStorage,location:{replace:p=>dest.push(p)},console,Date};
  await vm.runInNewContext(inline,context);
  return {dest,signOut,error:store.get('homelinkAuthError')||''};
}
{
  const v=await run({existingRole:'tenant',requestedRole:'manager'});
  assert.deepEqual(v.dest,['index.html']);assert.equal(v.signOut,1);assert.match(v.error,/cannot sign in as Manager/);
}
{
  const v=await run({existingRole:'manager',requestedRole:'manager'});
  assert.deepEqual(v.dest,['pages/manager_dashboard.html']);assert.equal(v.signOut,0);
}
{
  const v=await run({existingRole:'tenant',requestedRole:'contractor',mode:'signup'});
  assert.deepEqual(v.dest,['signup.html']);assert.match(v.error,/approval/);
}
{
  const v=await run({existingRole:'contractor',requestedRole:'contractor'});
  assert.deepEqual(v.dest,['pages/contractor_view.html']);
}
{
  const v=await run({existingRole:null,requestedRole:'manager'});
  assert.deepEqual(v.dest,['index.html']);assert.match(v.error,/profile was not found/);
}
{
  const v=await run({existingRole:'manager',requestedRole:'manager',age:999999999});
  assert.deepEqual(v.dest,['index.html']);assert.match(v.error,/expired/);
}
// Ensure the old inline Google OAuth routines are removed. Otherwise a stale
// auth-ui.js may leave a redirect-only login active on the deployed website.
for (const file of ['index.html','signup.html']) {
  const page=fs.readFileSync(new URL('../'+file,import.meta.url),'utf8');
  assert.ok(!page.includes('async function signInWithGoogle()'));
  assert.ok(!page.includes('async function signUpWithGoogle()'));
  assert.match(page,/auth-ui\.js\?v=20261014-rolefix2/);
}
{
  const v=await run({existingRole:'tenant',requestedRole:'manager',storage:'local'});
  assert.deepEqual(v.dest,['index.html']);assert.match(v.error,/cannot sign in as Manager/);
}
{
  const v=await run({existingRole:'tenant',requestedRole:'tenant',omitIntent:true});
  assert.deepEqual(v.dest,['index.html']);assert.match(v.error,/expired/);
}
{
  const v=await run({existingRole:' Manager ',requestedRole:'manager'});
  assert.deepEqual(v.dest,['pages/manager_dashboard.html']);
}
const callback=fs.readFileSync(new URL('../google-callback.html',import.meta.url),'utf8');
assert.match(callback,/localStorage.getItem\(KEY\)/);
console.log('Google role checks and legacy OAuth fallback regression tests passed');
